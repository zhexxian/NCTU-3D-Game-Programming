//
// 3D Game Programming
// NCTU
// Instructor: SAI-KEUNG WONG
//
#include "TutorialApplication.h"
#include <iostream>
using namespace std;
using namespace Ogre;
BasicTutorial_00::BasicTutorial_00(void) {
	mFlgMovingNode = true;
	mToggle = 2.1; //must be initialized!!!
}

void BasicTutorial_00::chooseSceneManager(void)
{
	mSceneMgr = mRoot
		->createSceneManager(ST_EXTERIOR_CLOSE); 
}

void BasicTutorial_00::createScene(void) 
{
	mSceneMgr->setSkyDome(true, "Examples/CloudySky", 5, 8);
	
	//mSceneMgr->setSkyDome(true, "Examples/MySky", 5, 8);
	mSNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
	Entity *ent = mSceneMgr->createEntity("model", "sphere.mesh");
	mSNode->attachObject(ent);

}

bool BasicTutorial_00::frameStarted(const Ogre::FrameEvent& evt)
{
	cout << "frameStarted" << endl;
	   if(mWindow->isClosed())
        return false;

    if(mShutDown)
        return false;

    //Need to capture/update each device
    mKeyboard->capture(); //try to disable it
    mMouse->capture();	//try to disable it
	///////////////////////////
	mToggle += evt.timeSinceLastFrame;
	if (mToggle > 2.0) mToggle = 2.1;
	if (mKeyboard->isKeyDown(OIS::KC_A)) {
		
		if (mToggle > 2.0) {
			mFlgMovingNode = !mFlgMovingNode;
			mToggle = 0.0;
			system("pause");
		}
		//mFlgMovingNode = !mFlgMovingNode;

	}
	Vector3 pos;
	static Real a = 0.0;
	if (mFlgMovingNode) {
		a += evt.timeSinceLastFrame;

		pos.y = sin(a)*50;
		mSNode->setPosition(pos);
	}
	//


	return true;
}
bool BasicTutorial_00::frameRenderingQueued(const Ogre::FrameEvent& evt)
{
	cout << "frameRenderingQueued" << endl;
	return true;
}
bool BasicTutorial_00::frameEnded(const Ogre::FrameEvent& evt)
{
	cout << "frameEnded" << endl;

	return true;
}
int main(int argc, char *argv[]) {
	BasicTutorial_00 app;
	app.go();  
	return 0;
}
