//
// 3D Game Programming
// NCTU
// Instructor: SAI-KEUNG WONG
//
#include "TutorialApplication.h"

//using namespace Ogre;
BasicTutorial_00::BasicTutorial_00(void) {}

void BasicTutorial_00::createViewports(void)
{
    // Create one viewport, entire window
    Ogre::Viewport* vp = mWindow->addViewport(mCamera);
    vp->setBackgroundColour(Ogre::ColourValue(0,0,0));

    // Alter the camera aspect ratio to match the viewport
    mCamera->setAspectRatio(
        Ogre::Real(vp->getActualWidth()) / Ogre::Real(vp->getActualHeight()));
}

void BasicTutorial_00::chooseSceneManager(void)
{
	mSceneMgr = mRoot
		->createSceneManager(Ogre::ST_EXTERIOR_CLOSE); 
}

void BasicTutorial_00::createScene(void) 
{
	Ogre::ColourValue fadeColour(0.3, 0.3, 0.9);	
	//try me
	mSceneMgr->setFog(Ogre::FOG_LINEAR, fadeColour, 0.0, 50, 500); 
	mSceneMgr->setWorldGeometry("terrain.cfg");  
	//try me
	//mSceneMgr->setFog(FOG_LINEAR, fadeColour, 0.0, 50, 500);	
}


int main(int argc, char *argv[]) {
	BasicTutorial_00 app;
	app.go();  
	return 0;
}
