//
// 3D Game Programming
// NCTU
// Instructor: SAI-KEUNG WONG
//
#ifndef __BasicTutorial_00_h_
#define __BasicTutorial_00_h_
 
#include "BaseApplication.h"

class BasicTutorial_00 : public BaseApplication
{
private:
	Ogre::SceneNode *mSNode;
	bool mFlgMovingNode;
	Ogre::Real mToggle;
public:
	BasicTutorial_00(void);
	virtual void chooseSceneManager(void);
	virtual void createScene(void);
	virtual bool frameStarted(const Ogre::FrameEvent& evt);
	virtual bool frameRenderingQueued(const Ogre::FrameEvent& evt);
	virtual bool frameEnded(const Ogre::FrameEvent& evt);

};
 
#endif // #ifndef __BasicTutorial_00_h_