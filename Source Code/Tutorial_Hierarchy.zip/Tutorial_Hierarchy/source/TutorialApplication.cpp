//
// 3D Game Programming
// NCTU
// Instructor: SAI-KEUNG WONG
//
// Show A BUG to students.
// 
// node2->attachObject( ent2 ); // IMPORTANT
//
#include "TutorialApplication.h"

using namespace Ogre;
BasicTutorial_00::BasicTutorial_00(void) {}

void BasicTutorial_00::createScene(void) 
{
	mSceneMgr->setAmbientLight( ColourValue( 1, 1, 1 ) ); //bright
	//mSceneMgr->setAmbientLight( ColourValue( 0, 0, 0 ) );  //dark
	Entity *ent1 
		= mSceneMgr->createEntity( 
			"Robot", "robot.mesh" ); 

	SceneNode *node1 
		= mSceneMgr
		->getRootSceneNode()
		->createChildSceneNode( "RobotNode" ); 

	node1->attachObject( ent1 ); 

	Entity *ent2 
		= mSceneMgr->createEntity( 
			"Robot2", "robot.mesh" ); 


	SceneNode *node2 
		= node1->createChildSceneNode( 
		"RobotNode2", Vector3( 0, 50, 0 ) ); 
	
	node2->attachObject( ent2 ); // IMPORTANT

	//
	node1->translate( Vector3( 20, 0, 20 ) ); 

	//node2->translate( Vector3( 20, 0, 20 ) ); 

}


int main(int argc, char *argv[]) {
	BasicTutorial_00 app;
	app.go();  
	return 0;
}
