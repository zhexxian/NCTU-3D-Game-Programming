//
// 3D Game Programming
// NCTU
// Instructor: SAI-KEUNG WONG
//
#include "TutorialApplication.h"

using namespace Ogre;
BasicTutorial_00::BasicTutorial_00(void) {}

void BasicTutorial_00::createViewports(void)
{
	// Create one viewport
    Ogre::Viewport* vp = mWindow->addViewport(
		mCamera, 
		0,		//z-order
		0.25,	//x-coordinate
		0.12,	//y-coordinate
		0.45,	//width
		0.6		//height
		);

    vp->setBackgroundColour(Ogre::ColourValue(0,1,0)); //green

    // Alter the camera aspect ratio to match the viewport
    mCamera->setAspectRatio(
        Ogre::Real(vp->getActualWidth()) / Ogre::Real(vp->getActualHeight()));
}

void BasicTutorial_00::createScene(void) 
{
	mSceneMgr->setAmbientLight( ColourValue( 1, 1, 1 ) ); //bright
	//mSceneMgr->setAmbientLight( ColourValue( 0, 0, 0 ) );  //dark
	Entity *ent2 
		= mSceneMgr
		->createEntity( "Robot2", "robot.mesh" ); 

	SceneNode *node2 
		= mSceneMgr
		->getRootSceneNode()
		->createChildSceneNode( 
		"RobotNode2", Vector3( 50, 0, 0 ) ); 

	node2->attachObject( ent2 ); 
}


int main(int argc, char *argv[]) {
	BasicTutorial_00 app;
	app.go();  
	return 0;
}
