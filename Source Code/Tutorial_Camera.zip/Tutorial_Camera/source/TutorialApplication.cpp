//
// 3D Game Programming
// NCTU
// Instructor: SAI-KEUNG WONG
//
#include "TutorialApplication.h"

using namespace Ogre;
BasicTutorial_00::BasicTutorial_00(void) {}

void BasicTutorial_00::createCamera(void)
{
	mCamera = mSceneMgr->createCamera("PlayerCam");

	mCamera->setPosition(Vector3(0,300,1));

	mCamera->lookAt(Vector3(0,0,0));

	mCamera->setNearClipDistance(5);

	//using OgreBites::SdkTrayListener
	mCameraMan = new OgreBites::SdkCameraMan(mCamera);   // create a default camera controller
}

void BasicTutorial_00::createScene(void) 
{
	mSceneMgr->setAmbientLight( ColourValue( 1, 1, 1 ) ); //bright
	//mSceneMgr->setAmbientLight( ColourValue( 0, 0, 0 ) );  //dark
	Entity *ent2 
		= mSceneMgr
		->createEntity( "Robot2", "robot.mesh" ); 

	SceneNode *node2 
		= mSceneMgr
		->getRootSceneNode()
		->createChildSceneNode( 
		"RobotNode2", Vector3( 50, 0, 0 ) ); 

	node2->attachObject( ent2 ); 
}


int main(int argc, char *argv[]) {
	BasicTutorial_00 app;
	app.go();  
	return 0;
}
