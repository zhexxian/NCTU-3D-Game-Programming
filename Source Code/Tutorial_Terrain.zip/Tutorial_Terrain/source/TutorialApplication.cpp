//
// 3D Game Programming
// NCTU
// Instructor: SAI-KEUNG WONG
//
#include "TutorialApplication.h"

using namespace Ogre;
BasicTutorial_00::BasicTutorial_00(void) {}

void BasicTutorial_00::chooseSceneManager(void)
{
	mSceneMgr = mRoot
		->createSceneManager(ST_EXTERIOR_CLOSE); 
}

void BasicTutorial_00::createScene(void) 
{
	mSceneMgr->setWorldGeometry("terrain.cfg");  
}


int main(int argc, char *argv[]) {
	BasicTutorial_00 app;
	app.go();  
	return 0;
}
